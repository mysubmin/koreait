package com.example.membersdb;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@Controller
public class RegisterController {
    @Autowired
    private RegisterMapper registerMapper;
    @GetMapping("/register")
    public String getRegister() {
        return "register";
    }

    @PostMapping("/register")
    @ResponseBody
    public Map<String, Object> saveRegister(@ModelAttribute RegisterDto registerDto) {
        registerMapper.getRegister(registerDto);
        Map<String, Object> map = new HashMap<>();
        map.put("msg", "success");
        return map;
    }

    @GetMapping("/list")
    public String getList(Model model) {
        model.addAttribute("mem", registerMapper.getMemberAll());
        return "list";
    }

    @GetMapping("")
    public String getMain() {
        return "main";
    }


    @GetMapping("/update")
    public String getUpdate(Model model, @RequestParam int id) {
        model.addAttribute("mem", registerMapper.getMemberOne(id));
        return "update";
    }

    @PostMapping("/update")
    @ResponseBody
    public Map<String, Object> setUpdate(@ModelAttribute RegisterDto registerDto) {
        registerMapper.setUpdate(registerDto);
        return Map.of("msg", "success");
    }

    @GetMapping("/delete")
    public String deleteMember(@RequestParam int id) {
        registerMapper.deleteMember(id);
        return "list";
    }

}
