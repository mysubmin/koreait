package com.example.membersdb;

import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface RegisterMapper {
    @Insert("INSERT INTO members VALUES(NULL, #{userid}, #{username}, #{passwd} , #{level} )" )
    void getRegister(RegisterDto registerDto);

    @Select("SELECT * FROM members " +
            "WHERE userid = #{userid} AND passwd = #{passwd}")
    RegisterDto checkLogin(RegisterDto registerDto);

    @Select("SELECT * FROM members ORDER BY id DESC")
    List<RegisterDto> getMemberAll();

    @Select("SELECT * FROM members WHERE id = #{id}")
    RegisterDto getMemberOne(int id);

    @Update("UPDATE members SET " +
            "userid = #{userid}, username = #{username}, " +
            "passwd = #{passwd}, level = #{level} WHERE id = #{id}")
    void setUpdate(RegisterDto registerDto);

    @Delete("DELETE FROM members WHERE id = #{id}")
    void deleteMember(int id);

}
