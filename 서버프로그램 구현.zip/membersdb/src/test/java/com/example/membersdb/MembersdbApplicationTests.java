package com.example.membersdb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MembersdbApplicationTests {

	@Test
	void contextLoads() {
	}

}
