package com.example.membersdb;

import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface RegisterMapper {
    @Insert("INSERT INTO users VALUES(NULL, #{email}, #{firstName}, #{lastName} , #{passwd}, #{enabled} )" )
    void getRegister(RegisterDto registerDto);


    @Select("SELECT * FROM users ORDER BY id DESC")
    List<RegisterDto> getMemberAll();

    @Select("SELECT * FROM users WHERE id = #{id}")
    RegisterDto getMemberOne(int id);

    @Update("UPDATE users SET " +
            "email = #{email}, firstName = #{firstName}, lastName = #{lastName}, " +
            "passwd = #{passwd}, enabled = #{enabled} WHERE id = #{id}")
    void setUpdate(RegisterDto registerDto);

    @Delete("DELETE FROM users WHERE id = #{id}")
    void deleteMember(int id);

}
