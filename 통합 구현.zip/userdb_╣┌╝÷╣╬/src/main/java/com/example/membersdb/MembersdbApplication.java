package com.example.membersdb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MembersdbApplication {

	public static void main(String[] args) {
		SpringApplication.run(MembersdbApplication.class, args);
	}

}
