create table users(
id int not null auto_increment,
email varchar(50) not null,
firstName varchar(20) not null,
lastName varchar(20) not null,
passwd varchar(20) not null,
enabled boolean not null,
primary key(id)
);