package com.example.employees.mappers;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface CalendarMapper {
}
