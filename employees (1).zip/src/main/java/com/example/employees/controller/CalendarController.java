package com.example.employees.controller;

import com.example.employees.mappers.CalendarMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class CalendarController {

    @Autowired
    private CalendarMapper calendarMapper;

    @GetMapping("/admin/calendar")
    public String getCalendar(Model model) {
        return "admin/calendar";
    }
}
