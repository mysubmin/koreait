package com.example.employees.dto;

import lombok.Data;

@Data
public class LevelDto {
    private int korEmpLevelCode;
    private String korEmpLevelName;
}
