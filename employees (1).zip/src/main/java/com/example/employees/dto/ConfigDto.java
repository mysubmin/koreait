package com.example.employees.dto;

import lombok.Data;

@Data
public class ConfigDto {
    private String code;
    private String title;
    private String color;
}
