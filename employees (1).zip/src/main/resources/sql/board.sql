use tb_koreait;

create table kor_board(
kor_board_id int not null auto_increment, -- 보기, 수정, 삭제
kor_board_notice char(1) default 'N',
kor_board_writer varchar(20),
kor_board_subject varchar(255),
kor_board_content text,
kor_board_upload_name varchar(255),
kor_board_upload_url varchar(30),
kor_board_upload_size bigint,
kor_board_upload_trans varchar(255),
kor_board_visit int,
kor_board_reply_grp int, -- 원본 + 답글을 하나의 그룹으로 묶기 위한 번호
kor_board_reply_grp_seq int, -- 답글을 정렬하기 위한 순서값
kor_board_reply_grp_seq_indent int, -- 답글(1), 답글 답글(2), 답글 답글 답글(3)
kor_board_regdate datetime,
primary key(kor_board_id)
);

-- 게시판 정렬 알고리즘
create table test_board(
subject varchar(255),
grp int,
grp_seq int,
grp_seq_indent int
);

-- 게시물 등록
INSERT INTO test_board VALUES("1번 원본 게시물입니다.", 1, 1, 1);
INSERT INTO test_board VALUES("2번 원본 게시물입니다.", 2, 1, 1);
INSERT INTO test_board VALUES("3번 원본 게시물입니다.", 3, 1, 1);

INSERT INTO test_board VALUES("2번 답글입니다.", 2, 1, 1);
INSERT INTO test_board VALUES("1번 답글입니다.", 1, 1, 1);

INSERT INTO test_board VALUES("2번 답글 답글입니다.", 2, 2, 2);

INSERT INTO test_board VALUES("1번 답글 답글입니다.", 1, 2, 2);

SELECT * FROM test_board ORDER BY grp DESC, grp_seq ASC;

-- 일치하는 검색 =
SELECT * FROM 테이블이름 WHERE 검색컬럼 = 검색어;
ex) SELECT * FROM test_board WHERE subject = '검색어'; --제목 검색
SELECT * FROM test_board WHERE subject = '1번';

-- 유사어 검색 LIKE : 검색어가 포함된 내용을 검색 - 속도가 느림
ex) SELECT * FROM 테이블이름 WHERE 검색컬럼 LIKE '%검색어%';
SELECT * FROM test_board WHERE subject LIKE '%원본%';

-- 게시판 환경 설정 테이블
create table config(
code varchar(10),
title varchar(100),
color varchar(10),
primary key(code)
);

-- 게시판 테이블 : kor_이름
create table kortb_code(
id int not null auto_increment,
subject varchar(100),
writer varchar(20),
content text,
grp int,
depth int,
primary key(id)
);