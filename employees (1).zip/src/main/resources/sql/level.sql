use tb_koreait;

create table kor_level(
kor_emp_level_code int,
kor_emp_level_name varchar(20)
);

INSERT INTO kor_level VALUES(7, "Level 7");
INSERT INTO kor_level VALUES(3, "Level 3");
INSERT INTO kor_level VALUES(2, "Level 2");
INSERT INTO kor_level VALUES(1, "Level 1");