use tb_koreait;

create table board(
id int not null auto_increment,
subject varchar(50),
writer varchar(20),
grp int,
depth int,
primary key(id)
);