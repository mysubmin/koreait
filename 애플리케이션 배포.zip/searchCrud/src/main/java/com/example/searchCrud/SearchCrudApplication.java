package com.example.searchCrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SearchCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(SearchCrudApplication.class, args);
	}

}
