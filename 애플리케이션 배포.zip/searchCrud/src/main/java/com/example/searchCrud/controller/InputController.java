package com.example.searchCrud.controller;

import com.example.searchCrud.dto.InputDto;
import com.example.searchCrud.mapper.InputMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class InputController {

    @Autowired
    private InputMapper inputMapper;

    @GetMapping("/input")
    public String getInput(){
        return "input";
    }


    @PostMapping("/save")
    public String setSave(@ModelAttribute InputDto inputDto) {
        inputMapper.setSave(inputDto);

        return "redirect:/output";
    }

    @GetMapping("/output")
    public String getList(
            Model model,
            @RequestParam(value="word", defaultValue = "") String word) {

        String searchQuery = "";

        if( word.equals("") ) {
            searchQuery = "";

        }else{ //검색어 있을 때
            searchQuery = "WHERE uId = '"+word+"'";
        }


        model.addAttribute("user", inputMapper.getMem(searchQuery));
        model.addAttribute("cnt", inputMapper.getMemCount(searchQuery));
        return "output";
    }

    @GetMapping("/edit")
    public String getEdit(@RequestParam int id, Model model) {
        model.addAttribute("user", inputMapper.getEdit(id));
        return "edit"; //html 파일 이름
    }

    @PostMapping("/edit")
    public String setEdit(@ModelAttribute InputDto inputDto) {
        inputMapper.setEdit(inputDto);
        return "redirect:/output";
    }


    @GetMapping("/delete")
    public String setDelete(@RequestParam int id) {
        inputMapper.setDelete(id);
        return "redirect:/output";
    }
}
