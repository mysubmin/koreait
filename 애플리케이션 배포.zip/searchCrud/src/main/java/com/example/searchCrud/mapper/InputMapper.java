package com.example.searchCrud.mapper;

import com.example.searchCrud.dto.InputDto;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface InputMapper {
    @Insert(" INSERT INTO user VALUES(NULL, #{uId}, #{uPWD}, #{uName} ) ")
    void setSave(InputDto inputDto);

    @Select("SELECT * from user ${searchQuery} order by id desc")
    List<InputDto> getMem(String searchQuery);

    @Select("SELECT COUNT(*) FROM user ${searchQuery}")
    int getMemCount(String searchQuery);

    @Select("SELECT * FROM user WHERE id = #{id}")
    InputDto getEdit(int id);

    @Update("UPDATE user SET uId = #{uId}, uPWD = #{uPWD}, uName = #{uName} WHERE id = #{id} ")
    void setEdit(InputDto inputDto);

    @Delete("DELETE FROM user WHERE id = #{id}")
    void setDelete(int id);

}
