package com.example.searchCrud.dto;

import lombok.Data;

@Data
public class InputDto {
    private int id;
    private String uId;
    private String uPWD;
    private String uName;
}
